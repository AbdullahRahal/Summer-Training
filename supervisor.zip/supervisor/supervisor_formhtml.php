<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    //Redirect to the login page if the user is not logged in
    header("Location: ../login.html");
    exit();
}

// Fetch admin information from the session
$csName = $_SESSION['cs_name'];
$csEmail = $_SESSION['username'];
$cscName = $_SESSION['cs_company_name'];
$csPhone = $_SESSION['cs_phone'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMU Internship</title>
    <link rel="stylesheet" href="nav-side.css" type="text/css">
    <link rel="stylesheet" href="supervisor_form.css" type="text/css">
    <script src="supervisor_forms.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

</head>
<body>
    <header>
        <nav>
            <div id="logodiv">
                <div class="logo" class="headerdivs" id="logocss">
                    <img src="https://upload.wikimedia.org/wikipedia/en/thumb/b/b8/EMU_Cyprus.svg/300px-EMU_Cyprus.svg.png" alt="EMU Logo">
                </div>
                <div class="headerdivs">
                    <h2>EMU Internship Supervisor</h2>
                </div>
            </div>
            <div class="top-bar-icon-container">
                <div class="user-info">
                    <a href="#" class="toggle-button"><i class="fas fa-user banner-icons"></i></a>
                    <div class="ddown-menu" id="menu-ddown" style="display: none;">
                        <h1>personal information</h1>
                        <table>
                            <tr>
                                <th>Name:</th>
                                <td><?php echo $csName; ?></td>
                            </tr>
                            <tr>
                                <th>Phone Number:</th>
                                <td><?php echo $csPhone; ?></td>
                            </tr>
                            <tr>
                                <th>Email:</th>
                                <td><?php echo $csEmail; ?></td>
                            </tr>
                            <tr>
                                <th>Company Name:</th>
                                <td><?php echo $cscName; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="menudiv">
                    <a href="#"><i class="fas fa-language banner-icons"></i></a>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt banner-icons"></i></a>
                </div>
                    <div id="menubar-button"><a href="#" class="menubar"><i class="fas fa-bars" id="menu-icon"></i></a></div>
                    <div class="dropdown-menu" id="menu-dropdown">
                        <a href="supervisor_homehtml.php">Home</a>
                        <a href="supervisor_formhtml.php">Forms</a>
                        <a href="supervisor_logbookhtml.php">Logbook</a>
                        <a href="supervisor_contacthtml.php">Contact</a>
                    </div>
            </div>
        </nav>
    </header>
    <div class="aside-container">
        <aside>
            <div class="side-div">
            <a href="supervisor_homehtml.php" class="side-element"><i class="fas fa-home list-icon"></i>Home</a>
            <a href="supervisor_formhtml.php" class="side-element"><i class="fas fa-file-alt list-icon"></i>Form</a>
            <a href="supervisor_logbookhtml.php" class="side-element"><i class="fas fa-book list-icon"></i>Logbook</a>
            <a href="supervisor_contacthtml.php" class="side-element"><i class="fas fa-envelope list-icon"></i>Contact</a>
            </div>
            </aside>
            </div>

        <main class="main-sec">
            <h1 style="border-bottom:2px solid #133e70;padding-bottom:5px;">Confirmation form</h1>
            <p id="anchor1">To fill in hard copy format of the form.<a href="#uploadCon">Click here</a></p>

            
            <div class="main-container">
                <div class="container1">
                    <form action="formsub.php" method="post">
                            <h3 style="border-bottom:2px solid #133e70;padding-bottom:5px;">Information about the Company and Trainee</h3>
                            <!-- Company Information -->
                            <div class="form-group">
                                <label for="companyName">Name of the Company *</label>
                                <input type="text" id="companyName" name="companyName" required>
                                <label for="workingFields">Working Field(s) *</label>
                                <input type="text" id="workingFields" name="workingFields" required>
                            </div>
                
                            <label for="postalAddress">Postal Address *</label>
                            <textarea id="postalAddress" name="postalAddress" rows="7" required></textarea>
                
                            <div class="form-group">
                                <label for="city">City *</label>
                                <input type="text" id="city" name="city" required>
                                
                                <label for="country">Country *</label>
                                <input type="text" id="country" name="country" required>
                            </div>
                
                            <div class="form-group">
                                <label for="fax">Fax</label>
                                <input type="text" id="fax" name="fax">                                
                                <label for="telephoneNumber">Telephone Number *</label>
                                <input type="tel" id="telephoneNumber" name="telephoneNumber" required>
                            </div>
                            <div class="form-group">
                                <label for="organizationalEmail">Organizational E-mail *</label>
                                <input type="email" id="organizationalEmail" name="organizationalEmail" required>
                                
                                <label for="organizationalWebAddress">Organizational Web Address *</label>
                                <input type="url" id="organizationalWebAddress" name="organizationalWebAddress" required>
                            </div>
                
                            <!-- Trainee Information -->
                            <div class="form-group">
                                <label for="traineeName">Name and Surname of the Trainee *</label>
                                <input type="text" id="traineeName" name="traineeName" required>
                                
                                <label for="trainingStartDate">Planned Training Start Date *</label>
                                <input type="date" id="trainingStartDate" name="trainingStartDate" required>
                                
                                <label for="trainingEndDate">Planned Training End Date *</label>
                                <input type="date" id="trainingEndDate" name="trainingEndDate" required>
                            </div>
                        </div>
                        <div class="container1">
                            <h3 style="border-bottom:2px solid #133e70;padding-bottom:5px;">The work to be done by the student</h3>
                
                            <div class="checkbox-menu">
                        
                                <div class="checkbox-item">
                                    <input type="checkbox" id="checkbox1" name="workOptions[]" value="Developing Software">
                                    <label for="checkbox1">Developing Software</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="checkbox2" name="workOptions[]" value="Operating System Installation and Maintenance">
                                    <label for="checkbox2">Operating System Installation and Maintenance</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="checkbox3" name="workOptions[]" value="Working as Part of a Team in a Large Software Project">
                                    <label for="checkbox3">Working as Part of a Team in a Large Software Project</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="checkbox4" name="workOptions[]" value="Hardware Fault Diagnosis and Repairs">
                                    <label for="checkbox4">Hardware Fault Diagnosis and Repairs</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="checkbox5" name="workOptions[]" value="Designing Web Pages">
                                    <label for="checkbox5">Designing Web Pages</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="checkbox6" name="workOptions[]" value="Developing a Web Application using ASP, .NET, PHP, etc.">
                                    <label for="checkbox6">Developing a Web Application using ASP, .NET, PHP, etc.</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="checkbox7" name="workOptions[]" value="Designing/ Working with Databases">
                                    <label for="checkbox7">Designing/ Working with Databases</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="checkbox8" name="workOptions[]" value="Learning to Use Complex Company Software">
                                    <label for="checkbox8">Learning to Use Complex Company Software</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="checkbox9" name="workOptions[]" value="Network Installation and Maintenance">
                                    <label for="checkbox9">Network Installation and Maintenance</label>
                                </div>
                                <br>
                                <b><label for="otherwork">others(if any):</label></b>
                                <textarea id="otherwork" name="workOptions[]" rows="6" required></textarea>
                    
                                <h3 style="border-bottom:2px solid #133e70;padding-bottom:5px;">Official Signature and Stamp of the Company</h3>
                    
                                <div class="upload-box" style="margin-bottom: 9%;">
                                    <label for="file">Upload E-stamp:</label>
                                    <input type="file" id="file" name="file">
                                </div>
                                <div class="upload-box">
                                    <label for="file">Upload E-signature:</label>
                                    <input type="file" id="file" name="file">
                                </div>
                                <button class="submitform">Submit</button>
                                </div>
                            </div>
                        </div> 
                    </form>
                </div>
            </div>
        </main>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                // Get references to the menubar button and the dropdown menu
                const menubarButton = document.getElementById("menubar-button");
                const dropdownMenu = document.querySelector(".dropdown-menu");
    
                // Add a click event listener to the menubar button
                menubarButton.addEventListener("click", function () {
                    // Toggle the visibility of the dropdown menu
                    if (dropdownMenu.style.display === "block") {
                        dropdownMenu.style.display = "none";
                    } else {
                        dropdownMenu.style.display = "block";
                    }
                });
            });
            
            // for user info
            document.querySelector(".toggle-button").addEventListener("click", function (event) {
                event.preventDefault(); // Prevent the default behavior of the anchor tag
                event.stopPropagation(); // Prevent the click event from bubbling up
                const dropdownMenu = document.getElementById("menu-ddown");
                dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
            });
            document.addEventListener("click", function(event) {
                const dropdownMenu = document.getElementById("menu-ddown");
                if (event.target !== document.querySelector(".toggle-button")) {
                    dropdownMenu.style.display = "none";
                }
            });
        </script>             
</body>
</html>
