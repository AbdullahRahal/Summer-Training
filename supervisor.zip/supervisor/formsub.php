<?php
// Include database connection
require_once 'db_connect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract form data
    $ccName = $_POST['companyName'];
    $ccField = $_POST['workingFields'];
    $ccAddress = $_POST['postalAddress'];
    $ccCity = $_POST['city'];
    $ccCountry = $_POST['country'];
    $ccTele = $_POST['telephoneNumber'];
    $ccEmail = $_POST['organizationalEmail'];
    $ccWebsite = $_POST['organizationalWebAddress'];
    $stdSDate = $_POST['trainingStartDate'];
    $stdEDate = $_POST['trainingEndDate'];
    $workToBeDone = $_POST['workOptions']; // Assuming 'workOptions' is an array of checkboxes

    // File upload handling for e-stamp and e-signature
    $uploadDir = 'uploads/';
    $eStampPath = '';
    $eSignaturePath = '';

    if (isset($_FILES['eStamp']) && $_FILES['eStamp']['error'] == 0) {
        $eStampFile = $_FILES['eStamp'];
        $eStampFileName = basename($eStampFile['name']);
        $eStampFilePath = $uploadDir . $eStampFileName;
        if (move_uploaded_file($eStampFile['tmp_name'], $eStampFilePath)) {
            $eStampPath = $eStampFilePath;
        } else {
            echo "Error uploading e-stamp file.";
        }
    }

    if (isset($_FILES['eSignature']) && $_FILES['eSignature']['error'] == 0) {
        $eSignatureFile = $_FILES['eSignature'];
        $eSignatureFileName = basename($eSignatureFile['name']);
        $eSignatureFilePath = $uploadDir . $eSignatureFileName;
        if (move_uploaded_file($eSignatureFile['tmp_name'], $eSignatureFilePath)) {
            $eSignaturePath = $eSignatureFilePath;
        } else {
            echo "Error uploading e-signature file.";
        }
    }

    // Prepare SQL to insert data into confirmations table
    $sql = "INSERT INTO confirmations (cc_name, cc_field, cc_address, cc_city, cc_country, cc_tele, cc_email, cc_website, std_s_date, std_e_date, work_to_be_done, e_stamp, e_signature) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssss", $ccName, $ccField, $ccAddress, $ccCity, $ccCountry, $ccTele, $ccEmail, $ccWebsite, $stdSDate, $stdEDate, $workToBeDone, $eStampPath, $eSignaturePath);

    // Execute the query
    if ($stmt->execute()) {
        echo "Confirmation submitted successfully";
        // Redirect or perform other success actions
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
