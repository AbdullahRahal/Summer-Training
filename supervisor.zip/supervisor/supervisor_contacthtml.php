<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    //Redirect to the login page if the user is not logged in
    header("Location: ../login.html");
    exit();
}

// Fetch admin information from the session
$csName = $_SESSION['cs_name'];
$csEmail = $_SESSION['username'];
$cscName = $_SESSION['cs_company_name'];
$csPhone = $_SESSION['cs_phone'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMU Internship</title>
    <link rel="stylesheet" href="nav-side.css" type="text/css">
    <link rel="stylesheet" href="supervisor_contact.css" type="text/css">
    <link rel="stylesheet" href="contactStyle.css" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <header>
        <nav>
            <div id="logodiv">
                <div class="logo" class="headerdivs" id="logocss">
                    <img src="https://upload.wikimedia.org/wikipedia/en/thumb/b/b8/EMU_Cyprus.svg/300px-EMU_Cyprus.svg.png" alt="EMU Logo">
                </div>
                <div class="headerdivs">
                    <h2>EMU Internship Supervisor</h2>
                </div>
            </div>
            <div class="top-bar-icon-container">
                <div class="user-info">
                    <a href="#" class="toggle-button"><i class="fas fa-user banner-icons"></i></a>
                    <div class="ddown-menu" id="menu-ddown" style="display: none;">
                        <h1>personal information</h1>
                        <table>
                            <tr>
                                <th>Name:</th>
                                <td><?php echo $csName; ?></td>
                            </tr>
                            <tr>
                                <th>Phone Number:</th>
                                <td><?php echo $csPhone; ?></td>
                            </tr>
                            <tr>
                                <th>Email:</th>
                                <td><?php echo $csEmail; ?></td>
                            </tr>
                            <tr>
                                <th>Company Name:</th>
                                <td><?php echo $cscName; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="menudiv">
                    <a href="#"><i class="fas fa-language banner-icons"></i></a>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt banner-icons"></i></a>
                </div>
                    <div id="menubar-button"><a href="#" class="menubar"><i class="fas fa-bars" id="menu-icon"></i></a></div>
                    <div class="dropdown-menu" id="menu-dropdown">
                        <a href="supervisor_homehtml.php">Home</a>
                        <a href="supervisor_formhtml.php">Forms</a>
                        <a href="supervisor_logbookhtml.php">Logbook</a>
                        <a href="supervisor_contacthtml.php">Contact</a>
                    </div>
            </div>
        </nav>
    </header>
    <div class="aside-container">
        <aside>
            <div class="side-div">
            <a href="supervisor_homehtml.php" class="side-element"><i class="fas fa-home list-icon"></i>Home</a>
            <a href="supervisor_formhtml.php" class="side-element"><i class="fas fa-file-alt list-icon"></i>Form</a>
            <a href="supervisor_logbookhtml.php" class="side-element"><i class="fas fa-book list-icon"></i>Logbook</a>
            <a href="supervisor_contacthtml.php" class="side-element"><i class="fas fa-envelope list-icon"></i>Contact</a>
            </div>
            </aside>


            <main class="main-sec">
                <div class="contact-contant">
                    <h1 style="border-bottom:2px solid #133e70;padding-bottom:5px;">contact information</h1>
                    <?php include '../student/get_contacts.php'; ?>
                </div>
            </main>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Get references to the menubar button and the dropdown menu
            const menubarButton = document.getElementById("menubar-button");
            const dropdownMenu = document.querySelector(".dropdown-menu");

            // Add a click event listener to the menubar button
            menubarButton.addEventListener("click", function () {
                // Toggle the visibility of the dropdown menu
                if (dropdownMenu.style.display === "block") {
                    dropdownMenu.style.display = "none";
                } else {
                    dropdownMenu.style.display = "block";
                }
            });
        });
        
        // for user info 
        document.querySelector(".toggle-button").addEventListener("click", function (event) {
            event.stopPropagation(); // Prevent the click event from bubbling up
                const dropdownMenu = document.getElementById("menu-ddown");
                dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
            });

            document.addEventListener("click", function (event) {
                const dropdownMenu = document.getElementById("menu-ddown");

                if (event.target !== document.querySelector(".toggle-button")) {
                    dropdownMenu.style.display = "none";
                }
            });
    </script>
</body>
</html>